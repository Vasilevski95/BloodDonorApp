﻿namespace WebAPI.Models
{
    public class DonationDBContext
    {
    }
}
